//Assignment 1 project
//uses everything from the first 5 lecture (? maybe only the first 4)
import java.util.Scanner;

public class Assignment1 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);

        //User input
        String firstName = in.next(); // uses next so as to not get "FIRST NAME LAST NAME" as 1 string
        String lastName = in.next();
        String barCode = in.next();
        double cost = in.nextDouble();
        double cash = in.nextDouble();
        double tax = 1.15; //static value

        // updates cost with added tax 
        cost = cost * tax;

        double change = cash - cost; // does the subtraction after cost + tax has been calculated.

        //Output text

        System.out.println("Customer (Last, First): " + lastName + " " + firstName );  // leaves space between both strings
        System.out.println("Item Number(product,Company):" + barCode.substring(6) + " " + barCode.substring(0,5) ); // substring(characters jumped, last character)
        System.out.println("Item Cost(+ Sales Tax): " + String.format("%.2f",cost));  //formats double with 2 numbers after decimal
        System.out.println("Change: " + String.format("%.2f",Math.abs(change))); // Uses absolute value since change has to be positive

        //Negative/Positive check of balance

        if (change <0){
            System.out.println(" Negative Balance (true/false): true" );
        }
        else{
            System.out.println("Negative Balance (True/False): False");
        }
    }
}